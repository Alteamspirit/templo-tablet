@echo off
echo ========================================
echo   El Templo - Servidor Local
echo ========================================
echo.
echo Iniciando servidor en http://localhost:8080
echo Abre el navegador en: http://localhost:8080
echo.
echo Para detener el servidor, cierra esta ventana.
echo.

:: Intentar con Python 3
python -m http.server 8080 2>nul
if %errorlevel% neq 0 (
    :: Intentar con Python 2
    python -m SimpleHTTPServer 8080 2>nul
    if %errorlevel% neq 0 (
        echo ERROR: No se encontro Python instalado.
        echo Instala Python desde https://www.python.org/downloads/
        echo O abre la app directamente en el navegador.
        pause
    )
)
pause
