/**
 * TEST AISLADO DEL PARSER DE CITAS
 */
const fakeGoogleResponse = {
    table: {
        rows: [
            { c: [{v:'nombre'},{v:'identificacion'},{v:'rito'},{v:'fecha'},{v:'hora'},{v:'rito'},{v:'fecha'},{v:'hora'}] },
            { c: [{v:'ana maria'},{v:'12345678a'},{v:'KIZUNA SANZEN KOAN'},{v:'30/5/25'},{v:'9:30'},{v:'KAO DETOX ESPALDA'},{v:'28/8/25'},{v:'19:15'}] },
            { c: [{v:'ramon'},{v:'87654321B'},{v:'SAMSKARA CALMA'},{v:'15/6/25'},{v:'11:00'},{v:null},{v:null},{v:null}] },
        ]
    }
};

function parseCitas(response) {
    const results = [];
    response.table.rows.slice(1).forEach(row => {
        if (!row.c || row.c.length < 2) return;
        const dni = row.c[1] ? (row.c[1].v || '').toString().trim() : '';
        if (!dni) return;
        for (let i = 2; i + 2 <= row.c.length - 1; i += 3) {
            const servicioCell = row.c[i];
            const fechaCell    = row.c[i + 1];
            const horaCell     = row.c[i + 2];
            const servicio = servicioCell ? (servicioCell.v || '').toString().trim() : '';
            if (!servicio) continue;
            const fecha = fechaCell ? (fechaCell.f || fechaCell.v || '').toString() : '';
            const hora  = horaCell  ? (horaCell.f  || horaCell.v  || '').toString() : '';
            results.push({ DNI: dni, Servicio: servicio, Fecha: fecha, Hora: hora });
        }
    });
    return results;
}

const resultado = parseCitas(fakeGoogleResponse);
console.log("Total citas:", resultado.length);
console.log(JSON.stringify(resultado, null, 2));
const normalize = (val) => (val || '').toString().toUpperCase().replace(/[^A-Z0-9]/g, '').trim();
const encontradas = resultado.filter(r => normalize(r.DNI) === normalize('12345678A'));
console.log("Para 12345678A:", encontradas.length, JSON.stringify(encontradas));
